#include <stdio.h>
#include <stdlib.h>

int main () {

		char ** mapa;
		int i;
			
		FILE* arq;
		arq = fopen("mapa.txt", "r"); // para abrir o arquivo 
		if (arq == 0 ){ // 
			printf ("erro na leitura do arquivo");
			exit(1);
		}
		
		for(i = 0; i <= 5; i++) {
			fscanf(arq, "%s", m[i]);
		}
		for(i = 0; i <= 5; i++) {
		printf ("%s\n", m[i]);
	}
	
return 0; 

}
